$(document).ready(function() {
  hideAllForm();
  $("#create-question").click(function() {
    console.log("create a Question !");
    toggleForm("question");
  });
  $("#create-idea").click(function() {
    console.log("create an Idea !");
    toggleForm("idea");
  });

  $("#content-question #title").add('#content-question #description').add('#content-idea #title').add('#content-idea #description').on("keyup", function() {
    var qaTitle = $('#title').val(),
      qaDesc = $('#description').val(),
      postPreview = $("#new-post-preview");

    if (qaTitle.length != 0 || qaDesc.length != 0) {
      postPreview.html(newPost(qaTitle, markdown.toHTML(qaDesc)));
      // console.log(newPost(content));
    } else {
      console.log("content is empty !");
      postPreview.empty();
    }
  })

  function newPost(title, description) {
    var self = this;
    var source = $("#new-post-template").html();
    var template = Handlebars.compile(source);
    console.log(title);
    
    /*
    var context = {
      title: "Why I can't login to my application on the server? it always redirects me back to login again",
      description: "I have a web application developed using laravel4 (php , MySql) every time I try to login with correct credentials it redirects me back to login again I don't know where is the problem The same project is working properly on another hosting and on localhost <br />The server support couldn't help me :(("
    };
    */

    var context = {
      postTitle: title,
      postDescription: description
    };
    var html = template(context);

    // console.log(html);
    return html;
  }

  function hideAllForm() {
    $("#content-question").hide();
    $("#content-idea").hide();
  }

  function toggleForm(formType) {
    $("#content-question").hide();
    $("#content-idea").hide();
    $("#content-default").fadeOut();

    if (formType.toString() === "question") {
      $("#content-question").slideDown();
    } else {
      $("#content-idea").slideDown();
    }
  }

  /*
  $("#content-input").on("focusin", function() {
    $(this).tinymce({
      theme: "modern",
      height: 125,
      menubar: false,
      plugins: [
        'autolink lists link image charmap preview hr anchor pagebreak',
        'insertdatetime',
        'emoticons'
      ],
      toolbar1: 'insertfile undo redo | bold italic alignleft aligncenter alignright alignjustify | preview media | link image emoticons'
    });
    
  });
  $("#content-input").on("blur", function() {
    $(this).tinymce().remove()
    console.log("TinyMCE removed !");
  });
  */
  // var renderer = new marked.Renderer()
  // qafeed.html(marked(content, {sanitize: true}));
});
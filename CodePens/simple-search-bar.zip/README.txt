A Pen created at CodePen.io. You can find this one at http://codepen.io/huange/pen/rbqsD.

 Just a simple responsive search bar.
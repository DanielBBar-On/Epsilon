<?php
class Bug extends AppModel {
	 var $name = 'Bug';
}
?>
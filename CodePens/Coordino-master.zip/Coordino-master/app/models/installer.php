<?php
class Installer extends AppModel {

	var $name = 'Answer';
	var $useTable = false;
	
}
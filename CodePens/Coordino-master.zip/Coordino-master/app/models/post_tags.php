<?php
	class PostTag extends AppModel
	{
	    var $name = 'PostTag';
		var $useTable = 'post_tags';
	}
?>